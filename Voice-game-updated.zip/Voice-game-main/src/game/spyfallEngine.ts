import type { SpyfallState, SpyfallAction, SpyPlayer } from './spyfallTypes'

export const LOCATIONS = ['Онгоцны буудал', 'Зоогийн газар', 'Эмнэлэг', 'Сургууль', 'Далайн эрэг', 'Кино театр', 'Банк', 'Цирк', 'Ой', 'Музей']
export const TIMER_SECONDS = 480

export function createInitialSpyfall(roster: SpyPlayer[]): SpyfallState {
  return { phase: 'lobby', players: roster, spyIndex: -1, location: '', revealIndex: 0, timeLeft: TIMER_SECONDS, votePick: null }
}

export function spyfallReducer(state: SpyfallState, action: SpyfallAction): SpyfallState {
  switch (action.type) {
    case 'START_GAME': {
      const spyIndex = Math.floor(Math.random() * state.players.length)
      const location = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)]
      return { ...state, phase: 'reveal', spyIndex, location, revealIndex: 0, timeLeft: TIMER_SECONDS, votePick: null }
    }
    case 'REVEAL_NEXT': {
      const next = state.revealIndex + 1
      if (next >= state.players.length) return { ...state, phase: 'playing', revealIndex: next }
      return { ...state, revealIndex: next }
    }
    case 'TICK': {
      if (state.phase !== 'playing') return state
      if (state.timeLeft <= 1) return { ...state, timeLeft: 0, phase: 'voting' }
      return { ...state, timeLeft: state.timeLeft - 1 }
    }
    case 'GO_VOTE': return state.phase === 'playing' ? { ...state, phase: 'voting' } : state
    case 'CAST_VOTE': return { ...state, votePick: action.index }
    case 'CONFIRM_VOTE': return state.votePick === null ? state : { ...state, phase: 'result' }
    case 'RESET': return { ...state, phase: 'lobby', spyIndex: -1, location: '', revealIndex: 0, timeLeft: TIMER_SECONDS, votePick: null }
    default: return state
  }
}

export type { SpyPlayer }
