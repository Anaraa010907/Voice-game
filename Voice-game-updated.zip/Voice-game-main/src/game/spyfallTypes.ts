export type SpyPlayer = { id: string; name: string; emoji: string; img?: string; host?: boolean }
export type SpyPhase = 'lobby' | 'reveal' | 'playing' | 'voting' | 'result'

export type SpyfallState = {
  phase: SpyPhase
  players: SpyPlayer[]
  spyIndex: number
  location: string
  revealIndex: number
  timeLeft: number
  votePick: number | null
}

export type SpyfallAction =
  | { type: 'START_GAME' }
  | { type: 'REVEAL_NEXT' }
  | { type: 'TICK' }
  | { type: 'GO_VOTE' }
  | { type: 'CAST_VOTE'; index: number }
  | { type: 'CONFIRM_VOTE' }
  | { type: 'RESET' }
