export const GAME_CONFIG = {
  startingMoney: 1500,
  startReward: 200,
  taxAmount: 100,
  jailFine: 50,
  jailMaxTurns: 3,
  maxBuildings: 5,
  buildingCost: 100,
  companyMultiplier: 8,
  doublesLimit: 3,
}
